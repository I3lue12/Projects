﻿namespace Zoo_Animal_Big_Small
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pbSmZebra = new System.Windows.Forms.PictureBox();
            this.pbSmMonkey = new System.Windows.Forms.PictureBox();
            this.pbSmLion = new System.Windows.Forms.PictureBox();
            this.pbLGZebra = new System.Windows.Forms.PictureBox();
            this.pbLGMonkey = new System.Windows.Forms.PictureBox();
            this.pbSmGir = new System.Windows.Forms.PictureBox();
            this.pbLGLion = new System.Windows.Forms.PictureBox();
            this.pbLGGiraf = new System.Windows.Forms.PictureBox();
            this.pbSmElephant = new System.Windows.Forms.PictureBox();
            this.pbLgElephant = new System.Windows.Forms.PictureBox();
            this.pbSmall = new System.Windows.Forms.PictureBox();
            this.pbBig = new System.Windows.Forms.PictureBox();
            this.pbArrow = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbSmZebra)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSmMonkey)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSmLion)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLGZebra)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLGMonkey)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSmGir)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLGLion)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLGGiraf)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSmElephant)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLgElephant)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSmall)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbBig)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbArrow)).BeginInit();
            this.SuspendLayout();
            // 
            // pbSmZebra
            // 
            this.pbSmZebra.Image = global::Zoo_Animal_Big_Small.Properties.Resources.SmallZebra;
            this.pbSmZebra.Location = new System.Drawing.Point(408, 510);
            this.pbSmZebra.Name = "pbSmZebra";
            this.pbSmZebra.Size = new System.Drawing.Size(89, 110);
            this.pbSmZebra.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSmZebra.TabIndex = 12;
            this.pbSmZebra.TabStop = false;
            this.pbSmZebra.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pbLgElephant_MouseDown);
            this.pbSmZebra.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pbLgElephant_MouseMove);
            this.pbSmZebra.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pbLgElephant_MouseUp);
            // 
            // pbSmMonkey
            // 
            this.pbSmMonkey.Image = global::Zoo_Animal_Big_Small.Properties.Resources.SmallMonkey;
            this.pbSmMonkey.Location = new System.Drawing.Point(318, 510);
            this.pbSmMonkey.Name = "pbSmMonkey";
            this.pbSmMonkey.Size = new System.Drawing.Size(84, 110);
            this.pbSmMonkey.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSmMonkey.TabIndex = 11;
            this.pbSmMonkey.TabStop = false;
            this.pbSmMonkey.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pbLgElephant_MouseDown);
            this.pbSmMonkey.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pbLgElephant_MouseMove);
            this.pbSmMonkey.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pbLgElephant_MouseUp);
            // 
            // pbSmLion
            // 
            this.pbSmLion.Image = global::Zoo_Animal_Big_Small.Properties.Resources.SmallLion;
            this.pbSmLion.Location = new System.Drawing.Point(224, 510);
            this.pbSmLion.Name = "pbSmLion";
            this.pbSmLion.Size = new System.Drawing.Size(88, 110);
            this.pbSmLion.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSmLion.TabIndex = 10;
            this.pbSmLion.TabStop = false;
            this.pbSmLion.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pbLgElephant_MouseDown);
            this.pbSmLion.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pbLgElephant_MouseMove);
            this.pbSmLion.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pbLgElephant_MouseUp);
            // 
            // pbLGZebra
            // 
            this.pbLGZebra.Image = global::Zoo_Animal_Big_Small.Properties.Resources.LargeZebra;
            this.pbLGZebra.Location = new System.Drawing.Point(202, 295);
            this.pbLGZebra.Name = "pbLGZebra";
            this.pbLGZebra.Size = new System.Drawing.Size(129, 195);
            this.pbLGZebra.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbLGZebra.TabIndex = 9;
            this.pbLGZebra.TabStop = false;
            this.pbLGZebra.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pbLgElephant_MouseDown);
            this.pbLGZebra.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pbLgElephant_MouseMove);
            this.pbLGZebra.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pbLgElephant_MouseUp);
            // 
            // pbLGMonkey
            // 
            this.pbLGMonkey.Image = global::Zoo_Animal_Big_Small.Properties.Resources.LargeMonkey;
            this.pbLGMonkey.Location = new System.Drawing.Point(253, 12);
            this.pbLGMonkey.Name = "pbLGMonkey";
            this.pbLGMonkey.Size = new System.Drawing.Size(173, 250);
            this.pbLGMonkey.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbLGMonkey.TabIndex = 8;
            this.pbLGMonkey.TabStop = false;
            this.pbLGMonkey.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pbLgElephant_MouseDown);
            this.pbLGMonkey.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pbLgElephant_MouseMove);
            this.pbLGMonkey.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pbLgElephant_MouseUp);
            // 
            // pbSmGir
            // 
            this.pbSmGir.Image = global::Zoo_Animal_Big_Small.Properties.Resources.SmallGiraffe;
            this.pbSmGir.Location = new System.Drawing.Point(24, 510);
            this.pbSmGir.Name = "pbSmGir";
            this.pbSmGir.Size = new System.Drawing.Size(89, 110);
            this.pbSmGir.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSmGir.TabIndex = 7;
            this.pbSmGir.TabStop = false;
            this.pbSmGir.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pbLgElephant_MouseDown);
            this.pbSmGir.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pbLgElephant_MouseMove);
            this.pbSmGir.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pbLgElephant_MouseUp);
            // 
            // pbLGLion
            // 
            this.pbLGLion.Image = global::Zoo_Animal_Big_Small.Properties.Resources.LargeLion;
            this.pbLGLion.Location = new System.Drawing.Point(24, 280);
            this.pbLGLion.Name = "pbLGLion";
            this.pbLGLion.Size = new System.Drawing.Size(160, 210);
            this.pbLGLion.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbLGLion.TabIndex = 6;
            this.pbLGLion.TabStop = false;
            this.pbLGLion.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pbLgElephant_MouseDown);
            this.pbLGLion.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pbLgElephant_MouseMove);
            this.pbLGLion.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pbLgElephant_MouseUp);
            // 
            // pbLGGiraf
            // 
            this.pbLGGiraf.Image = global::Zoo_Animal_Big_Small.Properties.Resources.LargeGiraffe;
            this.pbLGGiraf.Location = new System.Drawing.Point(365, 280);
            this.pbLGGiraf.Name = "pbLGGiraf";
            this.pbLGGiraf.Size = new System.Drawing.Size(101, 210);
            this.pbLGGiraf.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbLGGiraf.TabIndex = 5;
            this.pbLGGiraf.TabStop = false;
            this.pbLGGiraf.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pbLgElephant_MouseDown);
            this.pbLGGiraf.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pbLgElephant_MouseMove);
            this.pbLGGiraf.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pbLgElephant_MouseUp);
            // 
            // pbSmElephant
            // 
            this.pbSmElephant.Image = global::Zoo_Animal_Big_Small.Properties.Resources.SmallElephant;
            this.pbSmElephant.Location = new System.Drawing.Point(119, 510);
            this.pbSmElephant.Name = "pbSmElephant";
            this.pbSmElephant.Size = new System.Drawing.Size(99, 110);
            this.pbSmElephant.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSmElephant.TabIndex = 4;
            this.pbSmElephant.TabStop = false;
            this.pbSmElephant.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pbLgElephant_MouseDown);
            this.pbSmElephant.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pbLgElephant_MouseMove);
            this.pbSmElephant.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pbLgElephant_MouseUp);
            // 
            // pbLgElephant
            // 
            this.pbLgElephant.Image = global::Zoo_Animal_Big_Small.Properties.Resources.LargeElephant;
            this.pbLgElephant.Location = new System.Drawing.Point(33, 12);
            this.pbLgElephant.Name = "pbLgElephant";
            this.pbLgElephant.Size = new System.Drawing.Size(194, 250);
            this.pbLgElephant.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbLgElephant.TabIndex = 3;
            this.pbLgElephant.TabStop = false;
            this.pbLgElephant.Click += new System.EventHandler(this.pbLgElephant_Click);
            this.pbLgElephant.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pbLgElephant_MouseDown);
            this.pbLgElephant.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pbLgElephant_MouseMove);
            this.pbLgElephant.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pbLgElephant_MouseUp);
            // 
            // pbSmall
            // 
            this.pbSmall.Image = global::Zoo_Animal_Big_Small.Properties.Resources.Small;
            this.pbSmall.Location = new System.Drawing.Point(642, 406);
            this.pbSmall.Name = "pbSmall";
            this.pbSmall.Size = new System.Drawing.Size(144, 186);
            this.pbSmall.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbSmall.TabIndex = 2;
            this.pbSmall.TabStop = false;
            // 
            // pbBig
            // 
            this.pbBig.Image = global::Zoo_Animal_Big_Small.Properties.Resources.Big;
            this.pbBig.Location = new System.Drawing.Point(606, 89);
            this.pbBig.Name = "pbBig";
            this.pbBig.Size = new System.Drawing.Size(227, 273);
            this.pbBig.TabIndex = 1;
            this.pbBig.TabStop = false;
            // 
            // pbArrow
            // 
            this.pbArrow.Image = global::Zoo_Animal_Big_Small.Properties.Resources.GreenArrow;
            this.pbArrow.Location = new System.Drawing.Point(669, 640);
            this.pbArrow.Name = "pbArrow";
            this.pbArrow.Size = new System.Drawing.Size(100, 50);
            this.pbArrow.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbArrow.TabIndex = 13;
            this.pbArrow.TabStop = false;
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(969, 713);
            this.Controls.Add(this.pbArrow);
            this.Controls.Add(this.pbSmZebra);
            this.Controls.Add(this.pbSmMonkey);
            this.Controls.Add(this.pbSmLion);
            this.Controls.Add(this.pbLGZebra);
            this.Controls.Add(this.pbLGMonkey);
            this.Controls.Add(this.pbSmGir);
            this.Controls.Add(this.pbLGLion);
            this.Controls.Add(this.pbLGGiraf);
            this.Controls.Add(this.pbSmElephant);
            this.Controls.Add(this.pbLgElephant);
            this.Controls.Add(this.pbSmall);
            this.Controls.Add(this.pbBig);
            this.Name = "frmMain";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pbSmZebra)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSmMonkey)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSmLion)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLGZebra)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLGMonkey)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSmGir)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLGLion)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLGGiraf)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSmElephant)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbLgElephant)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbSmall)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbBig)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbArrow)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.PictureBox pbBig;
        private System.Windows.Forms.PictureBox pbSmall;
        private System.Windows.Forms.PictureBox pbLgElephant;
        private System.Windows.Forms.PictureBox pbSmElephant;
        private System.Windows.Forms.PictureBox pbLGGiraf;
        private System.Windows.Forms.PictureBox pbLGLion;
        private System.Windows.Forms.PictureBox pbSmGir;
        private System.Windows.Forms.PictureBox pbLGMonkey;
        private System.Windows.Forms.PictureBox pbLGZebra;
        private System.Windows.Forms.PictureBox pbSmLion;
        private System.Windows.Forms.PictureBox pbSmMonkey;
        private System.Windows.Forms.PictureBox pbSmZebra;
        private System.Windows.Forms.PictureBox pbArrow;
    }
}

